#!/usr/bin/env bash
set -euo pipefail
export PATH=/workspace/poco-f7-turnip/venv/bin:/workspace/bl2-f7-env/host/usr/bin:$PATH
export BISON_PKGDATADIR=/workspace/bl2-f7-env/host/usr/share/bison
export M4=/workspace/bl2-f7-env/host/usr/bin/m4
export MESA_GIT_SHA1_OVERRIDE=9c7e022677
python3 /workspace/poco-f7-turnip/instrument.py
g++ -std=c++17 -Wall -Wextra -Werror /workspace/poco-f7-turnip/test-diagnostics.cc -o /workspace/poco-f7-turnip/test-diagnostics
/workspace/poco-f7-turnip/test-diagnostics
meson setup --reconfigure /workspace/poco-f7-turnip/build-diagnostic /workspace/poco-f7-turnip/mesa-instrumented --cross-file /workspace/poco-f7-turnip/android-aarch64.ini --wrap-mode=nofallback -Dbuildtype=release -Dplatforms=android -Dplatform-sdk-version=35 -Dandroid-stub=true -Dgallium-drivers= -Dvulkan-drivers=freedreno -Dvulkan-beta=false -Dfreedreno-kmds=kgsl -Db_lto=false -Degl=disabled -Dgles1=disabled -Dgles2=disabled -Dopengl=false -Dllvm=disabled -Dbuild-tests=false '-Dcpp_args=-Wno-error=c++11-narrowing'
ninja -C /workspace/poco-f7-turnip/build-diagnostic -j4 src/freedreno/vulkan/libvulkan_freedreno.so
python3 /workspace/poco-f7-turnip/package.py --diagnostic
