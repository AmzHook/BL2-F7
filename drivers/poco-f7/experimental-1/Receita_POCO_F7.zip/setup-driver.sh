#!/usr/bin/env bash
set -euo pipefail
source /workspace/bl2-f7-env/activate.sh
DRIVER_ROOT=/workspace/poco-f7-turnip
MESA_COMMIT=9c7e022677dfa3abb356c2b6732cbd2e25783d01
mkdir -p "$DRIVER_ROOT"
cd "$DRIVER_ROOT"
if [[ ! -d venv ]]; then python3 -m venv venv; fi
venv/bin/python -m pip install meson==1.12.1 ninja==1.13.2 Mako==1.4.3 MarkupSafe==3.0.4 PyYAML==6.0.3 packaging==26.3
python3 - <<'PY'
import os, subprocess, urllib.parse
u=urllib.parse.urlparse(os.environ.get('HTTPS_PROXY',''))
a=['sdkmanager']
if u.hostname:
 a += ['--proxy=http','--proxy_host='+u.hostname,'--proxy_port='+str(u.port or 80)]
subprocess.run([*a,'ndk;29.0.14206865'],check=True)
PY
if [[ ! -x /workspace/bl2-f7-env/host/usr/bin/bison || ! -x /workspace/bl2-f7-env/host/usr/bin/flex || ! -x /workspace/bl2-f7-env/host/usr/bin/m4 ]]; then
  (
    cd /workspace/bl2-f7-env/apt
    APT_ARGS=(-o Dir::State::lists=/workspace/bl2-f7-env/apt/lists -o Dir::Etc::sourcelist=/workspace/bl2-f7-env/apt/sources.list -o Dir::Etc::sourceparts=- -o APT::Sandbox::User=agent)
    apt-get "${APT_ARGS[@]}" update
    apt-get "${APT_ARGS[@]}" download flex bison libfl2 m4
    for package in flex_*.deb bison_*.deb libfl2_*.deb m4_*.deb; do dpkg-deb -x "$package" /workspace/bl2-f7-env/host; done
  )
fi
if [[ ! -d mesa/.git ]]; then
  git clone --depth 1 --single-branch --no-checkout --branch turnip/gen8 --filter=blob:none https://github.com/whitebelyash/mesa-unified.git mesa
  git -C mesa fetch --depth 1 origin "$MESA_COMMIT"
  git -C mesa checkout "$MESA_COMMIT"
fi
test "$(git -C mesa rev-parse HEAD)" = "$MESA_COMMIT"
test -z "$(git -C mesa status --porcelain)"
mkdir -p ndk-pkgconfig
python3 - <<'PY'
from pathlib import Path
root=Path('/workspace/poco-f7-turnip')
ndk=Path('/workspace/bl2-f7-env/android-sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/linux-x86_64')
assert (ndk/'bin/aarch64-linux-android35-clang').exists()
cross=f'''[binaries]
c = '{ndk}/bin/aarch64-linux-android35-clang'
cpp = ['{ndk}/bin/aarch64-linux-android35-clang++', '-fno-exceptions', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables', '-static-libstdc++']
ar = '{ndk}/bin/llvm-ar'
strip = '{ndk}/bin/llvm-strip'
c_ld = 'lld'
cpp_ld = 'lld'
pkg-config = '/usr/bin/pkg-config'
[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'armv8'
endian = 'little'
[properties]
needs_exe_wrapper = true
pkg_config_libdir = '/workspace/poco-f7-turnip/ndk-pkgconfig'
[built-in options]
c_link_args = ['-Wl,-z,max-page-size=16384']
cpp_link_args = ['-Wl,-z,max-page-size=16384']
'''
pc=f'''prefix={ndk}/sysroot
libdir=${{prefix}}/usr/lib/aarch64-linux-android/35
includedir=${{prefix}}/usr/include
Name: zlib
Description: Android NDK zlib
Version: 1.3.0.1
Libs: -L${{libdir}} -lz
Cflags: -I${{includedir}}
'''
for name,text in [('android-aarch64.ini',cross),('ndk-pkgconfig/zlib.pc',pc)]:
 p=root/name
 if not p.exists() or p.read_text()!=text:p.write_text(text)
PY
export PATH="$DRIVER_ROOT/venv/bin:/workspace/bl2-f7-env/host/usr/bin:$PATH"
export BISON_PKGDATADIR=/workspace/bl2-f7-env/host/usr/share/bison
export M4=/workspace/bl2-f7-env/host/usr/bin/m4
meson --version
ninja --version
bison --version
