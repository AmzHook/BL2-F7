from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

root = Path('/workspace/poco-f7-turnip')
parser = argparse.ArgumentParser()
parser.add_argument('--diagnostic', action='store_true')
args = parser.parse_args()
build = root / ('build-diagnostic' if args.diagnostic else 'build-android')
source = root / 'mesa'
toolchain = Path('/workspace/bl2-f7-env/android-sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/linux-x86_64/bin')
commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == '9c7e022677dfa3abb356c2b6732cbd2e25783d01'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
version = (source / 'VERSION').read_text().strip()
header = (source / 'include/vulkan/vulkan_core.h').read_text()
header_version = re.search(r'^#define VK_HEADER_VERSION (\d+)$', header, re.M).group(1)
out = root / 'out'
stage = root / ('package-diagnostic' if args.diagnostic else 'package')
out.mkdir(exist_ok=True)
stage.mkdir(exist_ok=True)
library = stage / 'libvulkan_freedreno.so'
shutil.copyfile(build / 'src/freedreno/vulkan/libvulkan_freedreno.so', library)
subprocess.run([str(toolchain / 'llvm-strip'), '--strip-unneeded', str(library)], check=True)
subprocess.run([str(root / 'venv/bin/python'), str(source / 'bin/symbols-check.py'), '--lib', str(build / 'src/freedreno/vulkan/libvulkan_freedreno.so'), '--symbols-file', str(source / 'src/vulkan/vulkan-icd-android-symbols.txt'), '--nm', str(toolchain / 'llvm-nm')], check=True)
elf = subprocess.check_output(['readelf', '-h', str(library)], text=True)
assert 'AArch64' in elf and 'ELF64' in elf
segments = subprocess.check_output(['readelf', '-lW', str(library)], text=True)
loads = [line.split() for line in segments.splitlines() if line.strip().startswith('LOAD ')]
assert loads and all(int(line[-1], 16) >= 16384 for line in loads)
dynamic = subprocess.check_output(['readelf', '-d', str(library)], text=True)
needed = re.findall(r'\(NEEDED\).*\[([^]]+)\]', dynamic)
expected = {'libhardware.so', 'liblog.so', 'libnativewindow.so', 'libsync.so', 'libm.so', 'libz.so', 'libdl.so', 'libc.so'}
assert set(needed) == expected
symbols = subprocess.check_output([str(toolchain / 'llvm-nm'), '-D', '--defined-only', str(library)], text=True)
assert [line.split()[-1] for line in symbols.splitlines()] == ['HMI']
binary = library.read_bytes()
assert b'Adreno (TM) 825' in binary
assert b'/dev/kgsl-3d0' in binary
if args.diagnostic:
    assert b'PocoF7-Turnip' in binary
    assert b'build=Experimental-1-Diag' in binary
    assert b'physical_device_ready gpu=' in binary
    assert b'pipeline kind=%s count=%u cpu_us=' in binary
meta = {
    'schemaVersion': 1,
    'name': 'Turnip POCO F7 Experimental 1' + (' Diag' if args.diagnostic else ''),
    'description': 'Adreno 825 / Android ARM64 KGSL. Mesa gen8 9c7e022677, release build, no LTO. Target: Eden 4dc69c06f7. Device validation pending.' + (' Logcat tag: PocoF7-Turnip; pipeline batches >=5ms and errors.' if args.diagnostic else ''),
    'author': 'Mesa contributors; experimental local build',
    'packageVersion': '1',
    'vendor': 'Mesa',
    'driverVersion': f'Mesa {version} / Vulkan headers 1.4.{header_version}',
    'minApi': 35,
    'libraryName': library.name,
}
(stage / 'meta.json').write_text(json.dumps(meta, indent=2) + '\n')
archive = out / ('Turnip_POCO_F7_Experimental_1_Diag.zip' if args.diagnostic else 'Turnip_POCO_F7_Experimental_1.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ['meta.json', library.name]:
        info = zipfile.ZipInfo(name, (2026, 10, 13, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, (stage / name).read_bytes())
    for license_name in ['MIT', 'Apache-2.0', 'BSL-1.0']:
        z.write(source / 'licenses' / license_name, f'licenses/{license_name}')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert json.loads(z.read('meta.json'))['libraryName'] in z.namelist()
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
(out / (archive.name + '.sha256')).write_text(f'{sha}  {archive.name}\n')
manifest = {
    'source': 'https://github.com/whitebelyash/mesa-unified',
    'branch': 'turnip/gen8',
    'commit': commit,
    'mesa_version': version,
    'ndk': '29.0.14206865',
    'android_api': 35,
    'eden_target_revision': '4dc69c06f764a235bccd01afbfc765d9ddbebc9f',
    'eden_apk_inspected': False,
    'source_changes': ['src/freedreno/vulkan/tu_device.cc', 'src/freedreno/vulkan/tu_pipeline.cc'] if args.diagnostic else [],
    'diagnostic_patch_sha256': hashlib.sha256((root / 'diagnostics.patch').read_bytes()).hexdigest() if args.diagnostic else None,
    'instrumentation': ['successful instance/version', 'physical device/GPU initialization', 'graphics/compute pipeline batches >=5000 us', 'negative Vulkan pipeline results'] if args.diagnostic else [],
    'compiler_compatibility': '-Wno-error=c++11-narrowing (warnings retained)',
    'lto': False,
    'package_sha256': sha,
    'library_sha256': hashlib.sha256(binary).hexdigest(),
    'validation': ['native compilation', 'Mesa Android symbol contract', 'ARM64 ELF', '16 KiB LOAD segment alignment', 'Android shared dependencies', 'exported HMI', 'Adreno 825 identifier', 'KGSL device path', 'ZIP integrity'],
    'not_validated': ['load in supplied Eden APK', 'Vulkan device creation', 'gameplay correctness', 'FPS', 'thermals', 'device stability'],
}
(out / ('build-manifest-diagnostic.json' if args.diagnostic else 'build-manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'package': str(archive), 'size_bytes': archive.stat().st_size, 'sha256': sha, 'validation': 'PASS', 'device_validation': 'NOT RUN'}, indent=2))
