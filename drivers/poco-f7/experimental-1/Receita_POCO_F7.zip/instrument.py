from pathlib import Path
import difflib
import subprocess
import tarfile

root = Path('/workspace/poco-f7-turnip')
base = root / 'mesa'
dest = root / 'mesa-instrumented'
if not dest.exists():
    dest.mkdir()
    archive = root / 'mesa-source.tar'
    with archive.open('wb') as f:
        subprocess.run(['git', '-C', str(base), 'archive', '9c7e022677dfa3abb356c2b6732cbd2e25783d01'], stdout=f, check=True)
    with tarfile.open(archive) as t:
        t.extractall(dest, filter='data')
    archive.unlink()

changed = {}
device = 'src/freedreno/vulkan/tu_device.cc'
text = (base / device).read_text()
text = text.replace('#include "util/hex.h"\n', '#include "util/hex.h"\n#include "util/log.h"\n', 1)
anchor = '   instance->instance_idx = p_atomic_fetch_add(&instance_count, 1);'
assert text.count(anchor) == 1
text = text.replace(anchor, '''   mesa_log(MESA_LOG_INFO, "PocoF7-Turnip",
            "build=Experimental-1-Diag base=9c7e022677 Mesa=%s target=Eden-4dc69c06f7 pipeline_threshold_us=5000",
            PACKAGE_VERSION);
''' + anchor, 1)
anchor = '   device->is_perf_cntr_selectable &= (device->info->chip <= 7);'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '''
   mesa_log(MESA_LOG_INFO, "PocoF7-Turnip",
            "physical_device_ready gpu=%s chip_id=0x%" PRIx64 " page_size=%" PRIu64,
            device->name, device->dev_id.chip_id, os_page_size);
''', 1)
changed[device] = text

pipeline = 'src/freedreno/vulkan/tu_pipeline.cc'
text = (base / pipeline).read_text()
helper = '''static void
tu_poco_f7_pipeline_log(int64_t started_ns, const char *kind,
                       uint32_t count, VkResult result)
{
   const int64_t elapsed_us = (os_time_get_nano() - started_ns) / 1000;
   if (elapsed_us >= 5000 || result < 0) {
      mesa_log(result < 0 ? MESA_LOG_ERROR : MESA_LOG_INFO, "PocoF7-Turnip",
               "pipeline kind=%s count=%u cpu_us=%" PRIi64 " result=%d",
               kind, count, elapsed_us, (int) result);
   }
}

'''
text = text.replace('#include "util/u_debug.h"\n', '#include "util/u_debug.h"\n#include "util/log.h"\n#include "util/os_time.h"\n#include <inttypes.h>\n', 1)
anchor = '/* Emit IB that preloads the descriptors that the shader uses */'
assert text.count(anchor) == 1
text = text.replace(anchor, helper + anchor, 1)
for function, kind in [('tu_CreateGraphicsPipelines', 'graphics'), ('tu_CreateComputePipelines', 'compute')]:
    start = text.index(function + '(VkDevice device,')
    end = text.index('TU_GENX(' + function + ');', start)
    body = text[start:end]
    assert body.count('   MESA_TRACE_FUNC();') == 1
    assert body.count('   return final_result;') == 1
    body = body.replace('   MESA_TRACE_FUNC();', '   MESA_TRACE_FUNC();\n   const int64_t poco_f7_started_ns = os_time_get_nano();', 1)
    body = body.replace('   return final_result;', f'   tu_poco_f7_pipeline_log(poco_f7_started_ns, "{kind}", count, final_result);\n   return final_result;', 1)
    text = text[:start] + body + text[end:]
changed[pipeline] = text
patch = []
for name, text in changed.items():
    if (dest / name).read_text() != text:
        (dest / name).write_text(text)
    patch.extend(difflib.unified_diff((base / name).read_text().splitlines(keepends=True), text.splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name))
(root / 'diagnostics.patch').write_text(''.join(patch))
(root / 'diagnostic-helper.inc').write_text(helper)
print('Instrumented version/GPU initialization and graphics/compute pipeline batch durations.')
