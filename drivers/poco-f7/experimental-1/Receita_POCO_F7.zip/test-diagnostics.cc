#include <cassert>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <inttypes.h>

using VkResult = int32_t;
enum { MESA_LOG_INFO = 1, MESA_LOG_ERROR = 2 };
static int64_t now_ns;
static unsigned messages;
static int level;
static char last[256];
static int64_t os_time_get_nano() { return now_ns; }
static void mesa_log(int severity, const char *tag, const char *format, ...)
{
   assert(strcmp(tag, "PocoF7-Turnip") == 0);
   level = severity;
   messages++;
   va_list args;
   va_start(args, format);
   vsnprintf(last, sizeof(last), format, args);
   va_end(args);
}
#include "diagnostic-helper.inc"

int main()
{
   now_ns = 4999999;
   tu_poco_f7_pipeline_log(0, "graphics", 2, 0);
   assert(messages == 0);
   now_ns = 5000000;
   tu_poco_f7_pipeline_log(0, "graphics", 2, 0);
   assert(messages == 1 && level == MESA_LOG_INFO);
   assert(strcmp(last, "pipeline kind=graphics count=2 cpu_us=5000 result=0") == 0);
   now_ns = 7000000;
   tu_poco_f7_pipeline_log(6999000, "compute", 1, -4);
   assert(messages == 2 && level == MESA_LOG_ERROR);
   assert(strcmp(last, "pipeline kind=compute count=1 cpu_us=1 result=-4") == 0);
   tu_poco_f7_pipeline_log(6999000, "compute", 1, 1000297000);
   assert(messages == 2);
   puts("PASS: threshold, formatting, negative Vulkan results, positive Vulkan statuses");
}
